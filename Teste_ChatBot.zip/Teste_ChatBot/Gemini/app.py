import google.generativeai as gemini
from teste.ipynb import text_for_ia

Key = "AIzaSyC-9oOoUxE0v13DNuE37qBzClAfhJrxRJs"
gemini.configure(api_key=Key)
modelo = gemini.GenerativeModel("gemini-1.5-flash")
pergunta = text_for_ia;
resposta = modelo.generate_content(pergunta)
print(resposta.text)